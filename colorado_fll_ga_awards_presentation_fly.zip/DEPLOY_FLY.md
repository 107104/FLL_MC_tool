# Fly.io update: self-registration and JA Awards Portal

This update retains your existing SQLite database and uses `CREATE TABLE IF NOT EXISTS` to add awards and JA event assignments. Do not delete or reset your existing database.

## Upload to GitHub
Your existing repository may have `index.html`, `app.js`, and `cloud.js` at the repository root. This release uses the more reliable `static/` folder structure. Upload **all** files and folders from this package into your GitHub repository root, including `static/index.html`, `static/app.js`, `static/cloud.js`, `static/awards.js`, `server.py`, `requirements.txt`, and `Dockerfile`. Old root-level frontend files may remain but are unused.

If your Fly.io deployment UI cannot upload a folder, create a `static` folder in GitHub first and upload the four files into it.

Commit the changes, then redeploy your latest GitHub commit in Fly.io. The included Dockerfile uses port 8080, matching your fly.toml.

## Existing accounts and storage
Existing accounts remain in the SQLite database as long as Fly.io is using the **same persisted database**. New users can register themselves as viewers. In the Admin panel, change a registered person's role to `editor` or `ja`. For a JA, assign the exact event ID (visible in the workspace event data or event selector). Only assigned JAs and admins can enter or publish awards. Other signed-in users see published awards only.

For a custom domain, configure `GA_ALLOWED_ORIGINS` as comma-separated full origins, e.g. `https://fll-mc-tool.fly.dev,https://ga.example.org`. This should match your public URL exactly. Default is `https://fll-mc-tool.fly.dev`.

## Security and production readiness
This is an incremental implementation, not a security audit. Before wider public registration, add email verification, rate limiting on signup/login, password reset, abuse monitoring, database backups, and ideally approval/invitation controls for non-viewer roles. Users can self-register but cannot grant themselves privileges. JA draft awards are stored in a separate table and are not returned to ordinary users before publication.

**Important**: If your Fly deployment has no persistent volume or external database, redeployments may erase accounts and awards. Ensure `GA_DB_PATH` points to persistent storage, such as `/app/data/ga.sqlite3` on a mounted volume, and back it up.
